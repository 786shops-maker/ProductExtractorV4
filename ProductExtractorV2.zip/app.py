from flask import Flask, render_template, request
from extractor.parser import Parser
from extractor.exceptions import ProductExtractorError

app = Flask(__name__)
# Initialize the parser once at startup
parser = Parser(output_dir="downloads")

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/extract")
def extract():
    url = request.form.get("url", "").strip()
    if not url:
        return render_template("result.html", success=False, message="URL is required", url="")
    
    try:
        product = parser.parse(url)
        return render_template("result.html", success=True, message="Extraction successful!", url=url, product=product)
    except ProductExtractorError as e:
        return render_template("result.html", success=False, message=str(e), url=url)
    except Exception as e:
        return render_template("result.html", success=False, message=f"Unexpected error: {str(e)}", url=url)

@app.post("/extract-all")
def extract_all():
    urls = [u.strip() for u in request.form.get("urls", "").splitlines() if u.strip()]
    results = []
    
    for url in urls:
        try:
            product = parser.parse(url)
            results.append({"url": url, "success": True, "title": product.get("title"), "brand": product.get("brand")})
        except Exception as e:
            results.append({"url": url, "success": False, "error": str(e)})
    
    return render_template("result.html", success=True, message=f"Processed {len(urls)} URLs.", batch_results=results)

if __name__ == "__main__":
    app.run(debug=True, port=5000)