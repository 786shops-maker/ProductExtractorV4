"""
parser.py
Production orchestrator for ProductExtractor with safe image pipeline fallbacks.
"""
import logging
from .fetcher import WebFetcher
from .html_cleaner import HTMLCleaner
from .website_detector import WebsiteDetector
from .brand_detector import BrandDetector
from .title_parser import TitleParser
from .description_parser import DescriptionParser
from .price_parser import PriceParser
from .product_id import ProductIDExtractor
from .image_finder import ImageFinder
from .image_selector import ImageSelector
from .image_downloader import ImageDownloader
from .image_processor import ImageProcessor
from .output_writer import OutputWriter
from .exceptions import ProductExtractorError

logger = logging.getLogger("ProductExtractor")

class Parser:
    def __init__(self, output_dir="downloads"):
        self.fetcher = WebFetcher()
        self.cleaner = HTMLCleaner()
        self.website_detector = WebsiteDetector()
        self.brand_detector = BrandDetector()
        self.title_parser = TitleParser()
        self.description_parser = DescriptionParser()
        self.price_parser = PriceParser()
        self.product_id = ProductIDExtractor()
        
        # Image pipeline components
        self.image_finder = ImageFinder()
        self.image_selector = ImageSelector()
        self.downloader = ImageDownloader()
        self.processor = ImageProcessor()
        
        self.writer = OutputWriter(root_folder=output_dir)

    def parse(self, url: str):
        logger.info("Processing %s", url)
        try:
            # 1. Fetch and clean
            html = self.fetcher.download(url)
            clean_html = self.cleaner.clean(html)

            # 2. Extract metadata
            brand = self.brand_detector.detect(url)
            
            product = {
                "url": url,
                "website": self.website_detector.detect(url),
                "brand": brand,
                "product_id": self.product_id.extract(clean_html, url),
                "title": self.title_parser.parse(clean_html),
                "description": self.description_parser.final_description(clean_html, brand),
                "price_info": self.price_parser.parse(clean_html),
            }

            # 3. Extract and process images (SAFE FALLBACK)
            processed_images = []
            try:
                if self.image_finder and self.image_selector and self.downloader and self.processor:
                    images = self.image_finder.find(clean_html, url) or []
                    selected_images = self.image_selector.select(images) or []
                    
                    for img in selected_images:
                        try:
                            img_url = img.get("url", "") if isinstance(img, dict) else img
                            if img_url:
                                local_path = self.downloader.download(img_url)
                                processed_path = self.processor.process(local_path)
                                processed_images.append(processed_path)
                        except Exception as img_err:
                            logger.warning(f"Image processing failed for {img_url}: {img_err}")
            except Exception as img_pipeline_err:
                logger.warning(f"Image pipeline skipped (components may be incomplete): {img_pipeline_err}")

            product["images"] = processed_images

            # 4. Save output
            safe_brand = brand or "Unknown"
            pid = product["product_id"] or "no-id"
            self.writer.save_metadata(safe_brand, pid, product)
            self.writer.save_description(safe_brand, pid, product["description"])
            self.writer.save_html(safe_brand, pid, html)
            
            logger.info("Finished %s", url)
            return product

        except Exception as exc:
            logger.exception("Parser failed for %s", url)
            raise ProductExtractorError(f"Failed to parse {url}: {str(exc)}") from exc