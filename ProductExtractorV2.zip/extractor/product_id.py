"""
product_id.py
Extracts product IDs, SKUs, or style codes from URLs or HTML content.
"""
import re
import logging
from urllib.parse import urlparse

logger = logging.getLogger("ProductExtractor")

class ProductIDExtractor:
    def __init__(self):
        # Common SKU patterns: e.g., PM-62005, W-FB-SB-26-456904, BB-301
        self.sku_patterns = [
            r'\b[A-Z]{1,4}-\d{3,6}\b',          # e.g., PM-62005, BB-301
            r'\b[A-Z]{1,2}-[A-Z]{2}-[A-Z]{2}-\d{2}-\d{4,6}\b', # e.g., W-FB-SB-26-456904
            r'\b(?:SKU|Style\s*Code|Product\s*Code|Article)\s*[:\-]?\s*([A-Z0-9\-]{4,15})\b', # e.g., SKU: XYZ-1234
            r'\bModel\s*[:\-]?\s*([A-Z0-9\-]{4,15})\b'
        ]

    def extract(self, html: str, url: str = "") -> str:
        """
        Extracts the product ID. Prioritizes URL slug, then falls back to HTML scanning.
        """
        # 1. Try to extract from URL slug first (most reliable for modern e-commerce)
        if url:
            parsed = urlparse(url)
            path_parts = parsed.path.strip('/').split('/')
            if len(path_parts) > 0:
                slug = path_parts[-1]
                # If the slug looks like a product ID (contains numbers or is short and specific)
                if re.search(r'\d', slug) or len(slug) < 15:
                    # Clean up the slug (remove query params if any snuck in, though urlparse handles it)
                    clean_slug = slug.split('?')[0]
                    logger.info(f"Extracted product ID from URL slug: {clean_slug}")
                    return clean_slug.upper()

        # 2. Fallback: Scan HTML for SKU patterns
        html_upper = html.upper()
        for pattern in self.sku_patterns:
            match = re.search(pattern, html_upper)
            if match:
                # Group 1 is the actual ID if we used a capture group, otherwise the whole match
                product_id = match.group(1) if match.lastindex else match.group(0)
                logger.info(f"Extracted product ID from HTML: {product_id}")
                return product_id.strip()

        # 3. Ultimate fallback
        logger.warning("Could not find a specific product ID, using 'UNKNOWN-ID'")
        return "UNKNOWN-ID"