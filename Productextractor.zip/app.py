from flask import Flask,render_template,request
app=Flask(__name__)
@app.get("/")
def index(): return render_template("index.html")
@app.post("/extract")
def extract():
 url=request.form.get("url","").strip();
 return render_template("result.html",success=bool(url),message="Milestone 2 pending.",url=url)
@app.post("/extract-all")
def extract_all():
 urls=request.form.get("urls","").splitlines();
 return render_template("result.html",success=True,message=f"{len([u for u in urls if u.strip()])} URL(s) received.",url="")
if __name__=="__main__": app.run(debug=True)
