"""
price_parser.py
Universal price extractor.
"""

import re
from bs4 import BeautifulSoup


class PriceParser:

    PRICE_PATTERNS = [
        r"Rs\.?\s*([\d,]+)",
        r"PKR\s*([\d,]+)",
        r"Rs\s*([\d,]+)",
        r"([\d,]+)\s*PKR",
    ]

    def parse(self, html: str):

        soup = BeautifulSoup(html, "lxml")

        text = soup.get_text(" ", strip=True)

        prices = []

        for pattern in self.PRICE_PATTERNS:

            for match in re.findall(pattern, text, re.IGNORECASE):

                value = match.replace(",", "")

                try:
                    value = int(value)
                    prices.append(value)
                except:
                    pass

        prices = sorted(list(set(prices)))

        result = {
            "price": "",
            "sale_price": "",
            "currency": "PKR"
        }

        if len(prices) == 1:
            result["price"] = str(prices[0])

        elif len(prices) >= 2:
            result["sale_price"] = str(min(prices))
            result["price"] = str(max(prices))

        return result
