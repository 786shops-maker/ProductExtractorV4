"""
image_selector.py

Selects the best product images.
"""

from urllib.parse import urlparse


class ImageSelector:

    def __init__(self):

        self.max_images = 5

        self.bad_words = [

            "logo",
            "icon",
            "banner",
            "payment",
            "facebook",
            "instagram",
            "twitter",
            "youtube",
            "pinterest",
            "thumbnail",
            "thumb",
            "avatar",
            "favicon",
            "loading",
            "spinner"

        ]

    # -------------------------------------------------------

    def score(self, image):

        score = 0

        width = image.get("width", 0)
        height = image.get("height", 0)

        score += width * height

        url = image["url"].lower()

        # Prefer portrait images
        if height > width:
            score += 500000

        # Penalize unwanted images
        for word in self.bad_words:

            if word in url:
                score -= 10000000

        return score

    # -------------------------------------------------------

    def remove_duplicates(self, images):

        output = []

        seen = set()

        for img in images:

            url = img["url"]

            if url in seen:
                continue

            seen.add(url)

            output.append(img)

        return output

    # -------------------------------------------------------

    def remove_small(self, images):

        output = []

        for img in images:

            if img.get("width", 0) < 300:
                continue

            if img.get("height", 0) < 400:
                continue

            output.append(img)

        return output

    # -------------------------------------------------------

    def sort(self, images):

        images.sort(

            key=self.score,

            reverse=True

        )

        return images

    # -------------------------------------------------------

    def select(self, images):

        images = self.remove_duplicates(images)

        images = self.remove_small(images)

        images = self.sort(images)

        return images[:self.max_images]