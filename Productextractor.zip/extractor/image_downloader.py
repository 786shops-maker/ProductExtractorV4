"""
image_downloader.py
Download product images for later processing.
"""

from pathlib import Path
from urllib.parse import urlparse
import requests


class ImageDownloader:

    def __init__(self):
        self.session = requests.Session()

    def download_images(self, images, output_folder, limit=5):
        output = Path(output_folder)
        output.mkdir(parents=True, exist_ok=True)

        downloaded = []

        for index, image in enumerate(images[:limit], start=1):
            url = image["url"] if isinstance(image, dict) else str(image)

            try:
                response = self.session.get(url, timeout=30)
                response.raise_for_status()

                ext = self._extension(url)
                filename = output / f"image_{index}{ext}"

                with open(filename, "wb") as f:
                    f.write(response.content)

                downloaded.append(str(filename))

            except Exception as ex:
                print(f"Failed: {url}")
                print(ex)

        return downloaded

    def _extension(self, url):
        path = urlparse(url).path.lower()

        if path.endswith(".png"):
            return ".png"
        if path.endswith(".webp"):
            return ".webp"
        if path.endswith(".jpeg"):
            return ".jpeg"

        return ".jpg"
