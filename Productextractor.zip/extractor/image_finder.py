"""
image_finder.py
Locate high-quality product images from an HTML page.
"""

from bs4 import BeautifulSoup
from urllib.parse import urljoin


class ImageFinder:

    MIN_WIDTH = 400
    IGNORE = (
        "logo",
        "icon",
        "sprite",
        "banner",
        "payment",
        "facebook",
        "instagram",
        "twitter",
        "youtube",
    )

    def find(self, html: str, page_url: str):
        soup = BeautifulSoup(html, "lxml")

        found = []

        for img in soup.find_all("img"):

            src = (
                img.get("src")
                or img.get("data-src")
                or img.get("data-lazy-src")
                or img.get("data-original")
            )

            if not src:
                continue

            src = urljoin(page_url, src)

            lower = src.lower()

            if any(x in lower for x in self.IGNORE):
                continue

            width = self._to_int(img.get("width"))
            height = self._to_int(img.get("height"))

            score = (width or 0) * (height or 0)

            found.append(
                {
                    "url": src,
                    "width": width,
                    "height": height,
                    "score": score,
                }
            )

        # remove duplicates
        unique = {}
        for item in found:
            unique[item["url"]] = item

        images = list(unique.values())

        images.sort(key=lambda x: x["score"], reverse=True)

        return images[:5]

    def _to_int(self, value):
        try:
            return int(str(value).replace("px", ""))
        except Exception:
            return 0
