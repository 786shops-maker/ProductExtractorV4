"""
output_writer.py

Writes extracted product data to disk.
"""

import json
from pathlib import Path


class OutputWriter:

    def __init__(self, root_folder="downloads"):

        self.root = Path(root_folder)

        self.root.mkdir(
            parents=True,
            exist_ok=True
        )

    # ----------------------------------------------------

    def safe_name(self, text):

        text = str(text)

        bad = '<>:"/\\|?*'

        for ch in bad:
            text = text.replace(ch, "-")

        text = text.replace(" ", "-")

        while "--" in text:
            text = text.replace("--", "-")

        return text.strip("-")

    # ----------------------------------------------------

    def product_folder(
            self,
            brand,
            product_id
    ):

        brand = self.safe_name(brand)

        product = self.safe_name(
            f"{brand}-{product_id}"
        )

        folder = (
            self.root
            / brand
            / product
        )

        folder.mkdir(
            parents=True,
            exist_ok=True
        )

        return folder

    # ----------------------------------------------------

    def save_description(
            self,
            brand,
            product_id,
            text
    ):

        folder = self.product_folder(
            brand,
            product_id
        )

        filename = folder / (
            f"{self.safe_name(brand)}-{product_id}.txt"
        )

        with open(
                filename,
                "w",
                encoding="utf-8"
        ) as f:

            f.write(text)

        return filename

    # ----------------------------------------------------

    def save_html(
            self,
            brand,
            product_id,
            html
    ):

        folder = self.product_folder(
            brand,
            product_id
        )

        filename = folder / "source.html"

        with open(
                filename,
                "w",
                encoding="utf-8"
        ) as f:

            f.write(html)

        return filename

    # ----------------------------------------------------

    def save_metadata(
            self,
            brand,
            product_id,
            data
    ):

        folder = self.product_folder(
            brand,
            product_id
        )

        filename = folder / "metadata.json"

        with open(
                filename,
                "w",
                encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                indent=4,
                ensure_ascii=False
            )

        return filename

    # ----------------------------------------------------

    def save_log(
            self,
            brand,
            product_id,
            text
    ):

        folder = self.product_folder(
            brand,
            product_id
        )

        filename = folder / "extract.log"

        with open(
                filename,
                "a",
                encoding="utf-8"
        ) as f:

            f.write(text)
            f.write("\n")

        return filename