"""
description_parser.py

Production Description Parser
"""

import re
from bs4 import BeautifulSoup


class DescriptionParser:

    def __init__(self):
        pass

    # -------------------------------------------------

    def extract(self, html):

        soup = BeautifulSoup(html, "lxml")

        text = self.extract_description(soup)

        return self.clean(text)

    # -------------------------------------------------

    def extract_description(self, soup):

        selectors = [

            ".product-description",
            ".description",
            ".product__description",
            ".product-description-wrapper",
            ".tab-description",
            ".product-details",
            ".product-content",
            "#description",
            "#product-description",
            "[itemprop='description']"

        ]

        for selector in selectors:

            node = soup.select_one(selector)

            if node:

                txt = node.get_text(

                    "\n",

                    strip=True

                )

                if len(txt) > 50:

                    return txt

        return soup.get_text("\n", strip=True)

    # -------------------------------------------------

    def clean(self, text):

        text = text.replace("\r", "")

        text = re.sub(

            r"\n{3,}",

            "\n\n",

            text

        )

        lines = []

        for line in text.split("\n"):

            line = line.strip()

            if len(line) < 2:

                continue

            if line.lower() in (

                "share",

                "reviews",

                "review",

                "wishlist",

                "add to wishlist",

                "quantity",

                "size guide",

                "delivery",

                "returns"

            ):

                continue

            lines.append(line)

        return "\n".join(lines)

    # -------------------------------------------------

    def bullets(self, text):

        lines = []

        for line in text.split("\n"):

            line = line.strip()

            if line:

                lines.append("• " + line)

        return "\n".join(lines)

    # -------------------------------------------------

    def remove_duplicate_lines(self, text):

        seen = set()

        output = []

        for line in text.split("\n"):

            key = line.lower().strip()

            if key in seen:

                continue

            seen.add(key)

            output.append(line)

        return "\n".join(output)

    # -------------------------------------------------

    def final_description(self, html):

        text = self.extract(html)

        text = self.remove_duplicate_lines(text)

        return text