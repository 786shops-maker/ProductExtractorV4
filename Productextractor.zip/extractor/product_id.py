"""
product_id.py

Production Product ID extractor.
"""

import re
import json
from urllib.parse import urlparse


class ProductIDExtractor:
    """
    Determines the best product ID using multiple sources.
    Priority:

    1. JSON-LD sku
    2. HTML sku
    3. ProductID in HTML
    4. URL numeric ID
    5. URL slug
    """

    def get_product_id(self, url: str, html: str = "") -> str:

        # 1. JSON-LD SKU
        pid = self._jsonld_sku(html)
        if pid:
            return self._clean(pid)

        # 2. HTML SKU
        pid = self._html_sku(html)
        if pid:
            return self._clean(pid)

        # 3. Product ID in HTML
        pid = self._html_product_id(html)
        if pid:
            return self._clean(pid)

        # 4. URL numeric ID
        pid = self._url_numeric(url)
        if pid:
            return self._clean(pid)

        # 5. URL slug
        return self._url_slug(url)

    # --------------------------------------------------

    def _jsonld_sku(self, html):

        pattern = re.compile(
            r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>',
            re.I | re.S
        )

        for block in pattern.findall(html):

            try:
                data = json.loads(block)

                if isinstance(data, dict):

                    if data.get("@type") == "Product":
                        sku = data.get("sku")

                        if sku:
                            return str(sku)

            except Exception:
                pass

        return None

    # --------------------------------------------------

    def _html_sku(self, html):

        patterns = [

            r'"sku"\s*:\s*"([^"]+)"',

            r"SKU[: ]*</[^>]+>\s*<[^>]+>([^<]+)",

            r"sku[^a-zA-Z0-9]{1,10}([A-Za-z0-9_-]+)",

        ]

        for p in patterns:

            m = re.search(p, html, re.I | re.S)

            if m:
                return m.group(1)

        return None

    # --------------------------------------------------

    def _html_product_id(self, html):

        patterns = [

            r'"product_id"\s*:\s*"([^"]+)"',

            r'"productId"\s*:\s*"([^"]+)"',

            r'data-product-id="([^"]+)"',

            r'data-id="([^"]+)"'

        ]

        for p in patterns:

            m = re.search(p, html, re.I)

            if m:
                return m.group(1)

        return None

    # --------------------------------------------------

    def _url_numeric(self, url):

        nums = re.findall(r"\d{4,}", url)

        if nums:
            return nums[-1]

        return None

    # --------------------------------------------------

    def _url_slug(self, url):

        path = urlparse(url).path

        slug = path.strip("/").split("/")[-1]

        slug = slug.replace("-", "_")

        if slug == "":
            return "product"

        return slug

    # --------------------------------------------------

    def _clean(self, value):

        value = str(value)

        value = re.sub(r"[^A-Za-z0-9_-]", "", value)

        return value.strip("_-")