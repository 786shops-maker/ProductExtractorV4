"""
parser.py
Production orchestrator for ProductExtractorV3.
Adjust import names if any module names differ.
"""
from logger import logger
from exceptions import ProductExtractorError

from .fetcher import WebFetcher
from .html_cleaner import HTMLCleaner
from .website_detector import WebsiteDetector
from .brand_detector import BrandDetector
from .title_parser import TitleParser
from .description_parser import DescriptionParser
from .price_parser import PriceParser
from .product_id import ProductIDExtractor
from .image_finder import ImageFinder
from .image_selector import ImageSelector
from .image_downloader import ImageDownloader
from .image_processor import ImageProcessor
from .output_writer import OutputWriter


class Parser:
    def __init__(self):
        self.fetcher = WebFetcher()
        self.cleaner = HTMLCleaner()
        self.website_detector = WebsiteDetector()
        self.brand_detector = BrandDetector()
        self.title_parser = TitleParser()
        self.description_parser = DescriptionParser()
        self.price_parser = PriceParser()
        self.product_id = ProductIDExtractor()
        self.image_finder = ImageFinder()
        self.image_selector = ImageSelector()
        self.downloader = ImageDownloader()
        self.processor = ImageProcessor()
        self.writer = OutputWriter()

    def parse(self, url: str):
        logger.info("Processing %s", url)
        try:
            html = self.fetcher.fetch(url)
            clean_html = self.cleaner.clean(html)

            product = {}

            product["website"] = self.website_detector.detect(url)
            product["brand"] = self.brand_detector.detect(clean_html)
            product["product_id"] = self.product_id.extract(clean_html)
            product["title"] = self.title_parser.parse(clean_html)
            product["description"] = self.description_parser.parse(clean_html)
            product["price"] = self.price_parser.parse(clean_html)

            images = self.image_finder.find(clean_html)
            images = self.image_selector.select(images)

            processed = []
            for image in images:
                local = self.downloader.download(image)
                processed.append(self.processor.process(local))

            product["images"] = processed
            self.writer.write(product)
            logger.info("Finished %s", url)
            return product

        except Exception as exc:
            logger.exception("Parser failed")
            raise ProductExtractorError(str(exc)) from exc
